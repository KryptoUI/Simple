------------------------------------------------------------------------------------------------------------------

Guide with video - https://www.majorgeeks.com/files/details/remove_quick_access_in_windows_10_file_explorer.html
Backup your registry - https://www.majorgeeks.com/content/page/how_to_back_up_or_restore_the_windows_registry.html

------------------------------------------------------------------------------------------------------------------

To remove Quick Access in Windows 10 File Explorer, double-click this registry file and you're all set.

------------------------------------------------------------------------------------------------------------------

To restore File Explorer, open the Registry Editor and copy and paste:

HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer 

into the search bar at the top. 

Right-click on HubMode and choose delete
------------------------------------------------------------------------------------------------------------------