MajorGeeks.com Add or Remove Bing Disocver Button. 1.0

This file is intended to add or remove the Bing Discover Button from your Edge browser version 111.xx or better. Using these scripts is solely at your discretion and risk.

BACKUP. BACKUP. BACKUP. 
A registry backup should be done before proceeding:
https://www.majorgeeks.com/content/page/how_to_back_up_or_restore_the_windows_registry.html

To use, unzip the files to wherever you like. 
Click 'remove-bing-discover-from-edge.reg' to add the appropriate keys to your registry to remove the Bing Discover button or 'add-bing-discover-button-to-edge.reg' to add the button back.

Once added to the registry, you must open Edge and type the line 'edge://policy/' and click the refresh policy button or restart your machine. 

If you have any question check out the tutorial page
https://www.majorgeeks.com/content/page/how_to_remove_the_bing_discover_button_on_microsoft_edge.html

Geek it "till it MHz!